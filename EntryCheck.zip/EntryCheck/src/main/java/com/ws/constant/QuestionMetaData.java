package com.ws.constant;
/**
 * 
 */


public enum QuestionMetaData {

	
	QUESTION1_1("question1_1", "Fever and chills"),
	QUESTION1_2("question1_2", "Difficulty breathing or shortness of breath"),
	QUESTION1_3("question1_3", "Cough"),
	QUESTION1_4("question1_4", "Sore through, trouble swallowing"),
	QUESTION1_5("question1_5", "Runny nose/stuffy nose or nosal congestion"),
	
	QUESTION2_1("question2_1", "Decrease of loss of smell or teste"),
	QUESTION2_2("question2_2", "Nausea, vomiting, diarrhea, abdominal pain"),
	QUESTION2_3("question2_3", "Not feeling well, extreme tiredness, sore muscles"),
	
	QUESTION3_1("question3_1", "Have you travelled outside of Canada in the past 14 days?"),
	QUESTION3_2("question3_2", "Have you had close contact with a confirmed or probable case of COVID-19?");

	

	private final String label;

	private final String value;

	QuestionMetaData(String label, String value) {
		this.label = label;
		this.value = value;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	

}

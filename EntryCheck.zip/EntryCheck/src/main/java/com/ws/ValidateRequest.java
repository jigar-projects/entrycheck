package com.ws;

import com.ws.model.UserEntry;

public class ValidateRequest {

	private static final String ALLOWED_LITERAL = "No";
//	private static final String NOT_ALLOWED_LITERAL = "Yes";

	public static final boolean isAllowed(UserEntry userEntry) {
		if (ALLOWED_LITERAL.equals(userEntry.getQuestion1_1()) && ALLOWED_LITERAL.equals(userEntry.getQuestion1_2())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion1_3())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion1_4())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion1_5())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion2_1())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion2_2())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion2_3())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion3_1())
				&& ALLOWED_LITERAL.equals(userEntry.getQuestion3_2())) {
			return Boolean.TRUE;
		} else {
			return Boolean.FALSE;
		}
	}

}

package com.ws.assembler;

import org.springframework.stereotype.Component;

@Component
public class UserResourceAssembler {

}

package com.ws.advice;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ws.model.ErrorRespond;

@ControllerAdvice
public class GeneralAdvice {

	@ResponseBody
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<?> handleConstraintViolation(ConstraintViolationException ex) {

		ErrorRespond error = new ErrorRespond();
		error.setStatus(HttpStatus.BAD_REQUEST.value() + ", " + HttpStatus.BAD_REQUEST.getReasonPhrase());
		error.setMessage(ex.getMessage() + ", SQL State: " + ex.getSQLState());
		error.setDetails(ex.getSQLException().toString());

		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
}

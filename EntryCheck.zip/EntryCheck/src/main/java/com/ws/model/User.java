package com.ws.model;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString(callSuper = true, exclude = "password")
@NoArgsConstructor
@Entity
@Table(name = "user")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id", scope = Long.class)
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class User {
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "username", unique = true)
	private String username;

	@Column(name = "password")
	@JsonIgnore
	private String password;

	@Column(name = "email", unique = true)
	private String email;

	@Column(name = "enable")
	private boolean enable;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "phone")
	private String phone;

	@Column(name = "birthday")
	private Date birthday;

	@Column(name = "address")
	private String address;

	@Column(name = "postal")
	private String postalCode;

	@Column(name = "city")
	private String city;

	@Column(name = "record_created")
	private Timestamp recordCreated;

	public User(String username, String email, boolean enable, String firstName, String lastName, String password) {
		super();
		this.username = username;
		this.email = email;
		this.enable = enable;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
	}

}

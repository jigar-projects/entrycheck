package com.ws.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "userentry")
public class UserEntry {

	public UserEntry() {
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(name = "type")
	private String type;

	@Column(name = "location")
	private String location;

	@Column(name = "firstName")
	private String firstName;

	@Column(name = "lastName")
	private String lastName;

	@Column(name = "email")
	private String email;

	@Column(name = "mobile", nullable = false)
	private String mobile;

	@Column(name = "question1_1", nullable = false)
	private String question1_1;

	@Column(name = "question1_2", nullable = false)
	private String question1_2;

	@Column(name = "question1_3", nullable = false)
	private String question1_3;

	@Column(name = "question1_4", nullable = false)
	private String question1_4;

	@Column(name = "question1_5", nullable = false)
	private String question1_5;

	@Column(name = "question2_1", nullable = false)
	private String question2_1;

	@Column(name = "question2_2", nullable = false)
	private String question2_2;

	@Column(name = "question2_3", nullable = false)
	private String question2_3;

	@Column(name = "question3_1", nullable = false)
	private String question3_1;

	@Column(name = "question3_2", nullable = false)
	private String question3_2;

	@CreationTimestamp
	@Column(name = "createdAt", nullable = false, updatable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date createdAt;

	@UpdateTimestamp
	@Column(name = "updatedAt", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	private Date updatedAt;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the mobile
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 * @return the createdAt
	 */
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * @return the updatedAt
	 */
	public Date getUpdatedAt() {
		return updatedAt;
	}

	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the question1_1
	 */
	public String getQuestion1_1() {
		return question1_1;
	}

	/**
	 * @param question1_1 the question1_1 to set
	 */
	public void setQuestion1_1(String question1_1) {
		this.question1_1 = question1_1;
	}

	/**
	 * @return the question1_2
	 */
	public String getQuestion1_2() {
		return question1_2;
	}

	/**
	 * @param question1_2 the question1_2 to set
	 */
	public void setQuestion1_2(String question1_2) {
		this.question1_2 = question1_2;
	}

	/**
	 * @return the question1_3
	 */
	public String getQuestion1_3() {
		return question1_3;
	}

	/**
	 * @param question1_3 the question1_3 to set
	 */
	public void setQuestion1_3(String question1_3) {
		this.question1_3 = question1_3;
	}

	/**
	 * @return the question1_4
	 */
	public String getQuestion1_4() {
		return question1_4;
	}

	/**
	 * @param question1_4 the question1_4 to set
	 */
	public void setQuestion1_4(String question1_4) {
		this.question1_4 = question1_4;
	}

	/**
	 * @return the question1_5
	 */
	public String getQuestion1_5() {
		return question1_5;
	}

	/**
	 * @param question1_5 the question1_5 to set
	 */
	public void setQuestion1_5(String question1_5) {
		this.question1_5 = question1_5;
	}

	/**
	 * @return the question2_1
	 */
	public String getQuestion2_1() {
		return question2_1;
	}

	/**
	 * @param question2_1 the question2_1 to set
	 */
	public void setQuestion2_1(String question2_1) {
		this.question2_1 = question2_1;
	}

	/**
	 * @return the question2_2
	 */
	public String getQuestion2_2() {
		return question2_2;
	}

	/**
	 * @param question2_2 the question2_2 to set
	 */
	public void setQuestion2_2(String question2_2) {
		this.question2_2 = question2_2;
	}

	/**
	 * @return the question2_3
	 */
	public String getQuestion2_3() {
		return question2_3;
	}

	/**
	 * @param question2_3 the question2_3 to set
	 */
	public void setQuestion2_3(String question2_3) {
		this.question2_3 = question2_3;
	}

	/**
	 * @return the question3_1
	 */
	public String getQuestion3_1() {
		return question3_1;
	}

	/**
	 * @param question3_1 the question3_1 to set
	 */
	public void setQuestion3_1(String question3_1) {
		this.question3_1 = question3_1;
	}

	/**
	 * @return the question3_2
	 */
	public String getQuestion3_2() {
		return question3_2;
	}

	/**
	 * @param question3_2 the question3_2 to set
	 */
	public void setQuestion3_2(String question3_2) {
		this.question3_2 = question3_2;
	}

}

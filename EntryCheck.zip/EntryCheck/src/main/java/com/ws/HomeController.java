package com.ws;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ws.dto.CreateUserEntryRequestDTO;
import com.ws.model.UserEntry;
import com.ws.service.UserEntryService;

@Controller
public class HomeController {
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private UserEntryService userEntryService;

	@GetMapping("/")
	public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) {
		model.addAttribute("name", name);
		return "greeting";
	}
	
	@RequestMapping("/new")
	public String showNewProductPage(Model model) {
		CreateUserEntryRequestDTO createUserEntryRequestDTO  = new CreateUserEntryRequestDTO();
		model.addAttribute("userEntry", createUserEntryRequestDTO);
		
		return "new_user_entry";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("userEntry") CreateUserEntryRequestDTO createUserEntryRequestDTO) {
		
		UserEntry userEntry = modelMapper.map(createUserEntryRequestDTO, UserEntry.class);
		
		userEntryService.save(userEntry);
		
		if(ValidateRequest.isAllowed(userEntry)) {
			return "success";
		} else {
			return "fail";	
		}			
	}

}

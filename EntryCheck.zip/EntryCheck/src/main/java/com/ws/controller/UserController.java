package com.ws.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/users")
public class UserController {

	/*
	 * @Autowired private UserRepository userRepository;
	 */

	@GetMapping(value = "/get-all", produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, String> getAllUsers() {

		System.out.println("Inside USERS....... ");

		Map<String, String> sampleData = new HashMap<String, String>();

		sampleData.put("Joe", " Biedem");
		sampleData.put("Barack The", " Obama");

		return sampleData;
	}

	@GetMapping(value = "/test")
	public String test() {
		return "test";
	}

}

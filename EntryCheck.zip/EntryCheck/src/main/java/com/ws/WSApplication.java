package com.ws;

import java.time.LocalDateTime;
import java.util.Arrays;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication(

/*
 * exclude = { DataSourceAutoConfiguration.class,
 * DataSourceTransactionManagerAutoConfiguration.class,
 * HibernateJpaAutoConfiguration.class}
 */
)

public class WSApplication extends SpringBootServletInitializer {

	private static Class<WSApplication> applicationClass = WSApplication.class;

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(applicationClass);
	}

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(applicationClass, args);

		String[] beanNames = ctx.getBeanDefinitionNames();

		Arrays.sort(beanNames);

		for (String beanName : beanNames) {
			System.out.println(beanName);
		}
	}

	@RestController
	public static class WarInitializerController {

		@GetMapping("/test")
		public String handler(Model model) {
			model.addAttribute("date", LocalDateTime.now());
			return "WarInitializerApplication is up and running!";
		}
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}
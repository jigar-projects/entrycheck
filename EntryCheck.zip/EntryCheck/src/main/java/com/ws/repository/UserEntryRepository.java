package com.ws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ws.model.UserEntry;


public interface UserEntryRepository extends JpaRepository<UserEntry, Long> {

}

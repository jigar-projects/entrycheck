package com.ws.exception;

public class UserNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6375554154618149002L;

	public UserNotFoundException(Long id) {
		super("Could not find user with id: " + id);
	}
}
